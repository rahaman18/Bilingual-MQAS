def preprocess_query(query):
    return query.lower().strip()